package com.hospital.smart_hospital.common.enums;



public enum BloodGroup {

    A_POSITIVE,

    A_NEGATIVE,

    B_POSITIVE,

    B_NEGATIVE,

    AB_POSITIVE,

    AB_NEGATIVE,

    O_POSITIVE,

    O_NEGATIVE
}